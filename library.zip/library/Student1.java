package com.library;

public interface Student1 {
	void addstudent();
	void bookissuing();
	void bookreturning();
	void displaystudent();
	void displayallstudent();
	void removestudent();
	void updatestudent();
	
	
}
